package com.mirim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThymleafExApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThymleafExApplication.class, args);
	}

}
