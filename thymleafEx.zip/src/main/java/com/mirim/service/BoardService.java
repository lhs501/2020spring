package com.mirim.service;

import java.util.List;

import com.mirim.domain.Board;

public interface BoardService {

	List<Board> getBoardList(Board board);

	void insertBord(Board board);

	Board getBoard(Board board);

	void updateBoard(Board board);

	void deleteBoard(Board board);

}